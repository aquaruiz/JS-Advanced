let Person = require("./person").Person;

result.Person = Person;

// let Person = require('./person');        // with module.exports = Person

// result.Person = Person;