let sort = require("./dataFuncs").sort;
let filter = require("./dataFuncs").filter;

result.sort = sort;
result.filter = filter;