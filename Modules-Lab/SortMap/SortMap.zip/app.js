let sortMap = require("./helper-functions");
result.mapSort = sortMap;